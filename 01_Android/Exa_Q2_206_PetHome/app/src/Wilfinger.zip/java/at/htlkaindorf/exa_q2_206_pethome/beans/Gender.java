package at.htlkaindorf.exa_q2_206_pethome.beans;

public enum Gender {
    MALE,
    FEMALE
}
