package at.htlkaindorf.exa_q2_206_pethome.beans;

public enum Size {
    SMALL,
    MEDIUM,
    LARGE
}
