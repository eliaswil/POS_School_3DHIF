package at.htlkaindorf.exa_107_quiz.bl;

public enum Category {
    TINF,
    NVS,
    POS
}
